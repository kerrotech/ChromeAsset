(function () {
  var assetIdEl = document.getElementById("assetId");
  var serialNumberEl = document.getElementById("serialNumber");
  var annotatedLocationEl = document.getElementById("annotatedLocation");
  var statusEl = document.getElementById("status");

  function setStatus(text) {
    statusEl.textContent = text;
  }

  function setField(element, value) {
    element.textContent = value || "(empty)";
  }

  function setUnavailable(element) {
    element.textContent = "Unavailable";
  }

  function readAttribute(methodName, targetEl, friendlyName, done) {
    var api = chrome.enterprise.deviceAttributes;
    if (!api[methodName]) {
      setUnavailable(targetEl);
      done(friendlyName + " method unavailable");
      return;
    }

    api[methodName](function (value) {
      if (chrome.runtime.lastError) {
        setUnavailable(targetEl);
        done(friendlyName + ": " + chrome.runtime.lastError.message);
        return;
      }

      setField(targetEl, value);
      done(null);
    });
  }

  if (!chrome.enterprise || !chrome.enterprise.deviceAttributes) {
    setStatus("enterprise.deviceAttributes API not available.");
    setUnavailable(assetIdEl);
    setUnavailable(serialNumberEl);
    setUnavailable(annotatedLocationEl);
    return;
  }

  var pending = 3;
  var errors = [];

  function done(errorText) {
    if (errorText) {
      errors.push(errorText);
    }

    pending -= 1;
    if (pending !== 0) {
      return;
    }

    if (errors.length) {
      setStatus("Loaded with warnings: " + errors.join(" | "));
      return;
    }

    setStatus("Device attributes loaded.");
  }

  readAttribute("getDeviceAssetId", assetIdEl, "Asset ID", done);
  readAttribute("getDeviceSerialNumber", serialNumberEl, "Serial Number", done);
  readAttribute("getDeviceAnnotatedLocation", annotatedLocationEl, "Annotated Location", done);
})();
