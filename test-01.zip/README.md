# ChromeOS Device Attributes Kiosk App

This Chrome App launches fullscreen and displays ChromeOS enterprise device attributes using `chrome.enterprise.deviceAttributes`.

## Files

- `manifest.json` - App manifest and required permissions
- `background.js` - Launches the app window fullscreen
- `window.html` - UI shell
- `window.css` - Styling for kiosk display
- `window.js` - Reads and displays asset ID, serial number, and annotated location

## Important Requirements

- Device must be managed in Google Admin
- App must be force-installed as a kiosk app
- The app needs the `enterprise.deviceAttributes` permission
- Device fields should be configured in Admin Console (asset ID and annotated location)

## Deploy as Kiosk App

1. Open Google Admin Console.
2. Go to **Devices > Chrome > Apps & extensions > Kiosks**.
3. Add this app package (or upload in your publishing flow).
4. Set it to auto-launch if desired.

## Local Testing Notes

Chrome Apps are intended for ChromeOS managed deployments. API calls can fail on non-managed devices or non-kiosk contexts.
